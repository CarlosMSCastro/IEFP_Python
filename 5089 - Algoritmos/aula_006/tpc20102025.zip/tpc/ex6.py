print("--- Calculadora do desconto---")
preco = int(input("\nInsira o preço do artigo tabelado: "))
print(f"\nO preço final com o desconto aplicado é de {preco * 0.9} €.")

