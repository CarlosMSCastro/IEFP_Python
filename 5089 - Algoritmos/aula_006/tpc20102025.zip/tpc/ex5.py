print("--- Calculadora do numero anterior e inferior---")
favnumero = int(input("\nInsira o seu numero preferido: "))
print(f"O numero anterior ao seu numero preferido é {favnumero -1}, e o seguinte é {favnumero +1}.")


