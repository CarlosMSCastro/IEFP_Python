print("--- Calculadora de medidas do Quadrado---")
lado = float(input("Insira o lado do quadrado em cm: "))
area = lado*lado
perimetro = 4*lado
print(f"\nO quadrado tem {area:.2f} cm*2 de area, e {perimetro:.2f}cm de perimetro.")
